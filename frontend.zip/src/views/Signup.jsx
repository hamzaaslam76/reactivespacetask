import React, { Component } from "react";
import axios from "axios";
class Signup extends Component {
  state = {
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  };

  handleInputField = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };
  signUp = (e) => {
    e.preventDefault();
    const { password, confirmPassword } = this.state;
    if (password !== confirmPassword) {
      alert("Both password must be same");
    } else {
      axios
        .post("/api/v1/user/signup", this.state)
        .then((response) => {
          this.setState({ name: "" });
          this.setState({ email: "" });
          this.setState({ phone: "" });
          this.setState({ password: "" });
          this.setState({ confirmPassword: "" });
          console.log(this.state);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };
  render() {
    return (
      <>
        <div className="auth-wrapper">
          <div className="auth-inner">
            <form>
              <h3>Sign Up</h3>

              <div className="form-group">
                <label>Full name</label>
                <input
                  type="text"
                  name="name"
                  value={this.state.name}
                  className="form-control"
                  placeholder="First name"
                  required
                  onChange={this.handleInputField}
                />
              </div>

              <div className="form-group">
                <label>Email address</label>
                <input
                  type="text"
                  name="email"
                  value={this.state.email}
                  className="form-control"
                  placeholder="Email address"
                  required
                  onChange={this.handleInputField}
                />
              </div>

              <div className="form-group">
                <label>Phone Number</label>
                <input
                  type="phone"
                  name="phone"
                  value={this.state.phone}
                  className="form-control"
                  placeholder="Phone Number"
                  required
                  onChange={this.handleInputField}
                />
              </div>

              <div className="form-group">
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  value={this.state.password}
                  className="form-control"
                  placeholder="Enter password"
                  required
                  onChange={this.handleInputField}
                />
              </div>

              <div className="form-group">
                <label>Confirm Password</label>
                <input
                  type="password"
                  name="confirmPassword"
                  value={this.state.confirmPassword}
                  className="form-control"
                  placeholder="Confirm password"
                  required
                  onChange={this.handleInputField}
                />
              </div>

              <button
                className="btn btn-primary btn-block"
                onClick={this.signUp}
              >
                Sign Up
              </button>
              <p className="forgot-password text-right">
                Already registered <a href="/">sign in?</a>
              </p>
            </form>
          </div>
        </div>
      </>
    );
  }
}

export default Signup;
