import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, Redirect } from "react-router-dom";
import "./login.css";
function Login(props) {
  const [user, setUser] = useState({ email: "", password: "" });
  const [check, setCheck] = useState({ success: false });
  const handleField = (e) => {
    const { value, name } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };
  const login = (e) => {
    e.preventDefault();
    axios
      .post("/api/v1/user/login", user)
      .then((response) => {
        console.log(response);
        sessionStorage.setItem("accessToken", response.data.Token);
        sessionStorage.setItem("fullresult", JSON.stringify(response));
        setCheck({ success: true });
        props.afterLogin();
      })
      .catch((err) => {
        console.log(err);
      });
  };
  if (check.success) {
  }
  return (
    <>
      <div className="auth-wrapper">
        <div className="auth-inner">
          <form>
            <h3>Sign In</h3>

            <div className="form-group">
              <label>Email address</label>
              <input
                type="email"
                name="email"
                value={user.email}
                className="form-control"
                placeholder="Enter email"
                onChange={handleField}
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                value={user.password}
                className="form-control"
                placeholder="Enter password"
                onChange={handleField}
              />
            </div>

            <div className="form-group">
              <div className="custom-control custom-checkbox">
                <input
                  type="checkbox"
                  className="custom-control-input"
                  id="customCheck1"
                />
                <label className="custom-control-label" htmlFor="customCheck1">
                  Remember me
                </label>
              </div>
            </div>

            <button className="btn btn-primary btn-block" onClick={login}>
              Submit
            </button>
            <p className="forgot-password text-center">
              <Link to="/sign-up">create account</Link>
            </p>
            <p className="forgot-password text-right">
              Forgot <Link to="/sign-up">password?</Link>
            </p>
          </form>
        </div>
      </div>
    </>
  );
}
export default Login;
