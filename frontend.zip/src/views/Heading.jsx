import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import "./sidebar.css";
import PlacesTable from "./PlacesTable";
import AddPlace from "./AddPlace";
import Favorite from "./Favorite";
import NoMatch from "./NoMatch";
class Heading extends Component {
  constructor() {
    super();
  }
  render() {
    return (
      <Router>
        <div className="d-flex" id="wrapper">
          <div className="bg-light border-right" id="sidebar-wrapper">
            <div className="sidebar-heading">Tour Management System</div>
            <div className="list-group list-group-flush">
              <a className="list-group-item list-group-item-action bg-light">
                <Link to="/">Add Places</Link>
              </a>
              <a className="list-group-item list-group-item-action bg-light">
                <Link to="/searchplace">Search Places</Link>
              </a>
              <a className="list-group-item list-group-item-action bg-light">
                <Link to="/favorite"> Favorite Places</Link>
              </a>
            </div>
          </div>
          <div id="page-content-wrapper">
            <div className="container-fluid">
              <Switch>
                <Route exact path="/" component={AddPlace} />
                <Route exact path="/searchplace" component={PlacesTable} />
                <Route exact path="/favorite" component={Favorite} />
                <Route component={NoMatch}></Route>
              </Switch>
            </div>
          </div>
        </div>
      </Router>
    );
  }
}
export default Heading;
