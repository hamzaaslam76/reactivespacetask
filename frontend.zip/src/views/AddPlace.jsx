import React, { useState, useEffect } from "react";
import axios from "axios";
import "./login.css";
function AddPlace() {
  const [place, setPlace] = useState({
    name: "",
    address: "",
    phoneNumber: "",
    type: "",
  });

  const handleInputField = (e) => {
    const { value, name } = e.target;
    setPlace({
      ...place,
      [name]: value,
    });
  };
  const signUp = (e) => {
    e.preventDefault();
    axios
      .post("/api/v1/tour", place)
      .then((response) => {
        if (response.status === 201) {
          setPlace({ name: "" });
          setPlace({ address: "" });
          setPlace({ phoneNumber: "" });
          setPlace({ type: "" });
        }
      })
      .catch((err) => {
        console.log(err);
      });
    console.log(place);
  };
  return (
    <>
      <div className="auth-wrapper">
        <div className="auth-inner">
          <form>
            <h3>Add Place</h3>

            <div className="form-group">
              <label>Place name</label>
              <input
                type="text"
                name="name"
                value={place.name}
                className="form-control"
                placeholder="Place name"
                onChange={handleInputField}
              />
            </div>

            <div className="form-group">
              <label>Address</label>
              <input
                type="text"
                name="address"
                value={place.address}
                className="form-control"
                placeholder="Address"
                onChange={handleInputField}
              />
            </div>

            <div className="form-group">
              <label>Phone Number</label>
              <input
                type="phone"
                name="phoneNumber"
                value={place.phoneNumber}
                className="form-control"
                placeholder="Phone Number"
                onChange={handleInputField}
              />
            </div>

            <div className="form-group">
              <label>Place Type</label>
              <input
                type="text"
                name="type"
                value={place.type}
                className="form-control"
                placeholder="Place Type"
                onChange={handleInputField}
              />
            </div>

            <button className="btn btn-primary btn-block" onClick={signUp}>
              Save
            </button>
          </form>
        </div>
      </div>
    </>
  );
}

export default AddPlace;
