import React from 'react'

export default function NoMatch() {
    return (
        <div>
            No Path Matches
        </div>
    )
}
