import React, { useState, useEffect } from "react";
import { Table } from "react-bootstrap";
import axios from "axios";
function Favorite() {
  const [favorite, setFavorite] = useState([]);
  useEffect(() => {
    axios
      .get("/api/v1/user/userFavourit")
      .then((response) => {
        setFavorite(response.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
    return () => {};
  }, []);

  const handleDelete = (item) => {
    console.log(item);
    axios.delete(`/api/v1/user/deleteFavorite/${item.id}`).then((response) => {
      if (response) {
        let filterStudent = favorite.filter((s) => s.id !== item.id);
        setFavorite(filterStudent);
      }
    });
  };
  return (
    <>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Name</th>
            <th>Address</th>
            <th>PhoneNumber</th>
            <th>Type</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {favorite.map((item) => (
            <tr key={item.id}>
              <td>{item.tourId.name}</td>
              <td>{item.tourId.address}</td>
              <td>{item.tourId.phoneNumber}</td>
              <td>{item.tourId.type}</td>
              <td>
                <button
                  onClick={() => handleDelete(item)}
                  className="btn btn-danger"
                  type="button"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </>
  );
}

export default Favorite;
