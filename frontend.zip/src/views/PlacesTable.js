import React, { useState,useEffect}from 'react'
import { DataGrid, ColDef, ValueGetterParams } from '@material-ui/data-grid';
import { Button, TextField } from '@material-ui/core';
import  axios  from "axios";
export default function PlacesTable() {
  const [selectedrows, setselectedrows] = useState([]);
  const [alltour, setalltour] = useState([])
  const [find, setFind] = useState({search:''})
    useEffect(() => {
        axios
            .get('/api/v1/tour').then((response) => {
                let arr = [];
                response.data.ListOftours.map(data => {
                    let obj = data;
                    obj.id = data._id;
                    arr.push(obj);
                })
                setalltour(arr);
                }).catch((err) => {
                    console.log(err);
                })
        return () => {
            
        }
    }, []);
  const handleSearch = (e) => {
    const { value, name } = e.target;
    setFind({
      [name]: value,
    });
   }
    const columns = [
        // { field: '_id', headerName: 'ID', width: 70 },
        { field: 'name', headerName: 'Name', width: 255 },
        { field: 'address', headerName: 'Address', width: 255 },
        {
          field: 'phoneNumber',
          headerName: 'PhoneNumber',
         
          width: 200,
        },
        {
          field: 'type',
          headerName: 'Type',
          width: 255
        },
    ];
    
    return (<>
         
        <div style={{ marginLeft: "1%" }}>
        <Button  variant="contained" color="primary" onClick={() => {
                axios.post('/api/v1/user/addFavourit', selectedrows).then((response) => {
                    
                }).catch((err) => {
                    
                })
        }}>
          Click to add selected Places to favourite
        </Button>
        <TextField style={{ marginLeft: "40%" }} name="search" value={find.search} onChange={handleSearch} label="Search Place" /><Button style={{ marginTop: "1%" }} variant="contained" color="primary" onClick={() => {
          axios
          .get(`/api/v1/placeSearch?search=${find.search}`).then((response) => {
              let arr = [];
              response.data.ListOftours.map(data => {
                  let obj = data;
                  obj.id = data._id;
                  arr.push(obj);
              })
              setalltour(arr);
              }).catch((err) => {
                  console.log(err);
              })
         }}>
                Search
        </Button>
           
        </div>
        <div style={{ height: 400, width: '100%' }}>
            <DataGrid rows={alltour} columns={columns} pageSize={10} checkboxSelection  onSelectionModelChange={(e) => {
                  setselectedrows(e);
        }} />
        </div>
        
        </>
    )
}
