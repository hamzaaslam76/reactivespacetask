import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import react, { useState } from 'react';
import { BrowserRouter as Router, Switch, Route, Link,Redirect } from "react-router-dom";
import Signup from './views/Signup.jsx'
import Login from './views/Login'
import Heading from "./views/Heading";
import NoMatch from './views/NoMatch';
function App() {
  const [login, setlogin] = useState(false);
  const afterLogin=()=>{
    setlogin(!login);
  }
  return (
    // <Heading></Heading>
    <Router>
         
      {login == false ?
        <Switch>
          <Route
          exact
          path="/"
          render={(props) => (
            <Login {...props} afterLogin={afterLogin} />
            
          )}
      />
        <Route path="/sign-up" component={Signup} />
        <Route
          render={(props) => (
            <Login {...props} afterLogin={afterLogin} />
            
          )}
      />
      </Switch> :
        <Switch> 
        <Route exact path='/' component={Heading} />
        <Route component={NoMatch}></Route>  </Switch> } 
          
      
          
          
           
          
    </Router>
  );
}

export default App;
